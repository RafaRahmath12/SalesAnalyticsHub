import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    status: v.optional(v.union(v.literal("lead"), v.literal("prospect"), v.literal("active"), v.literal("inactive"))),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    if (args.status) {
      return await ctx.db
        .query("customers")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .collect();
    }
    
    return await ctx.db.query("customers").order("desc").collect();
  },
});

export const get = query({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    company: v.optional(v.string()),
    industry: v.optional(v.string()),
    status: v.union(v.literal("lead"), v.literal("prospect"), v.literal("active"), v.literal("inactive")),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db.insert("customers", {
      ...args,
      totalValue: 0,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("customers"),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    company: v.optional(v.string()),
    industry: v.optional(v.string()),
    status: v.optional(v.union(v.literal("lead"), v.literal("prospect"), v.literal("active"), v.literal("inactive"))),
    notes: v.optional(v.string()),
    lastContact: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
  },
});

export const getAnalytics = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const customers = await ctx.db.query("customers").collect();
    
    const statusCounts = customers.reduce((acc, customer) => {
      acc[customer.status] = (acc[customer.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const industryDistribution = customers.reduce((acc, customer) => {
      const industry = customer.industry || "Unknown";
      acc[industry] = (acc[industry] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const totalCustomers = customers.length;
    const totalValue = customers.reduce((sum, customer) => sum + customer.totalValue, 0);
    const avgValue = totalCustomers > 0 ? totalValue / totalCustomers : 0;
    
    return {
      totalCustomers,
      totalValue,
      avgValue,
      statusCounts,
      industryDistribution,
    };
  },
});
