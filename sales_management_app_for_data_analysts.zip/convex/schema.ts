import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  customers: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    company: v.optional(v.string()),
    industry: v.optional(v.string()),
    status: v.union(v.literal("lead"), v.literal("prospect"), v.literal("active"), v.literal("inactive")),
    totalValue: v.number(),
    lastContact: v.optional(v.number()),
    notes: v.optional(v.string()),
  })
    .index("by_status", ["status"])
    .index("by_email", ["email"])
    .index("by_company", ["company"]),

  sales: defineTable({
    customerId: v.id("customers"),
    amount: v.number(),
    product: v.string(),
    category: v.string(),
    status: v.union(v.literal("pending"), v.literal("closed"), v.literal("lost")),
    probability: v.number(), // 0-100
    expectedCloseDate: v.number(),
    actualCloseDate: v.optional(v.number()),
    salesRep: v.string(),
    notes: v.optional(v.string()),
  })
    .index("by_customer", ["customerId"])
    .index("by_status", ["status"])
    .index("by_sales_rep", ["salesRep"])
    .index("by_category", ["category"])
    .index("by_close_date", ["expectedCloseDate"]),

  activities: defineTable({
    customerId: v.id("customers"),
    type: v.union(v.literal("call"), v.literal("email"), v.literal("meeting"), v.literal("demo"), v.literal("follow-up")),
    description: v.string(),
    outcome: v.optional(v.string()),
    nextAction: v.optional(v.string()),
    scheduledFor: v.optional(v.number()),
  })
    .index("by_customer", ["customerId"])
    .index("by_type", ["type"])
    .index("by_scheduled", ["scheduledFor"]),

  targets: defineTable({
    salesRep: v.string(),
    period: v.string(), // "2024-Q1", "2024-01", etc.
    target: v.number(),
    achieved: v.number(),
    category: v.optional(v.string()),
  })
    .index("by_sales_rep", ["salesRep"])
    .index("by_period", ["period"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
