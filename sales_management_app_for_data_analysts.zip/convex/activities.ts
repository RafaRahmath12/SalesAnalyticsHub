import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    customerId: v.optional(v.id("customers")),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let activities;
    
    if (args.customerId) {
      activities = await ctx.db
        .query("activities")
        .withIndex("by_customer", (q) => q.eq("customerId", args.customerId!))
        .order("desc")
        .collect();
    } else {
      activities = await ctx.db.query("activities").order("desc").collect();
    }
    
    // Enrich with customer data
    const enrichedActivities = await Promise.all(
      activities.map(async (activity) => {
        const customer = await ctx.db.get(activity.customerId);
        return {
          ...activity,
          customer,
        };
      })
    );
    
    return enrichedActivities;
  },
});

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    type: v.union(v.literal("call"), v.literal("email"), v.literal("meeting"), v.literal("demo"), v.literal("follow-up")),
    description: v.string(),
    outcome: v.optional(v.string()),
    nextAction: v.optional(v.string()),
    scheduledFor: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const activityId = await ctx.db.insert("activities", args);
    
    // Update customer last contact
    await ctx.db.patch(args.customerId, {
      lastContact: Date.now(),
    });
    
    return activityId;
  },
});

export const getUpcoming = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const now = Date.now();
    const nextWeek = now + (7 * 24 * 60 * 60 * 1000);
    
    const activities = await ctx.db.query("activities").collect();
    
    const upcoming = activities
      .filter(activity => 
        activity.scheduledFor && 
        activity.scheduledFor >= now && 
        activity.scheduledFor <= nextWeek
      )
      .sort((a, b) => (a.scheduledFor || 0) - (b.scheduledFor || 0));
    
    // Enrich with customer data
    const enrichedActivities = await Promise.all(
      upcoming.map(async (activity) => {
        const customer = await ctx.db.get(activity.customerId);
        return {
          ...activity,
          customer,
        };
      })
    );
    
    return enrichedActivities;
  },
});
