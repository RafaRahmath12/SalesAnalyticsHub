import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    customerId: v.optional(v.id("customers")),
    status: v.optional(v.union(v.literal("pending"), v.literal("closed"), v.literal("lost"))),
    salesRep: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let sales;
    
    if (args.customerId) {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_customer", (q) => q.eq("customerId", args.customerId!))
        .order("desc")
        .collect();
    } else if (args.status) {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .collect();
    } else if (args.salesRep) {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_sales_rep", (q) => q.eq("salesRep", args.salesRep!))
        .order("desc")
        .collect();
    } else {
      sales = await ctx.db.query("sales").order("desc").collect();
    }
    
    // Enrich with customer data
    const enrichedSales = await Promise.all(
      sales.map(async (sale) => {
        const customer = await ctx.db.get(sale.customerId);
        return {
          ...sale,
          customer,
        };
      })
    );
    
    return enrichedSales;
  },
});

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    amount: v.number(),
    product: v.string(),
    category: v.string(),
    status: v.union(v.literal("pending"), v.literal("closed"), v.literal("lost")),
    probability: v.number(),
    expectedCloseDate: v.number(),
    salesRep: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const saleId = await ctx.db.insert("sales", args);
    
    // Update customer total value if sale is closed
    if (args.status === "closed") {
      const customer = await ctx.db.get(args.customerId);
      if (customer) {
        await ctx.db.patch(args.customerId, {
          totalValue: customer.totalValue + args.amount,
        });
      }
    }
    
    return saleId;
  },
});

export const update = mutation({
  args: {
    id: v.id("sales"),
    amount: v.optional(v.number()),
    product: v.optional(v.string()),
    category: v.optional(v.string()),
    status: v.optional(v.union(v.literal("pending"), v.literal("closed"), v.literal("lost"))),
    probability: v.optional(v.number()),
    expectedCloseDate: v.optional(v.number()),
    actualCloseDate: v.optional(v.number()),
    salesRep: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    const existingSale = await ctx.db.get(id);
    
    if (!existingSale) {
      throw new Error("Sale not found");
    }
    
    // Handle status change to closed
    if (updates.status === "closed" && existingSale.status !== "closed") {
      const customer = await ctx.db.get(existingSale.customerId);
      if (customer) {
        await ctx.db.patch(existingSale.customerId, {
          totalValue: customer.totalValue + existingSale.amount,
        });
      }
      updates.actualCloseDate = Date.now();
    }
    
    await ctx.db.patch(id, updates);
  },
});

export const getAnalytics = query({
  args: {
    period: v.optional(v.string()), // "month", "quarter", "year"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const sales = await ctx.db.query("sales").collect();
    const now = Date.now();
    const periodMs = {
      month: 30 * 24 * 60 * 60 * 1000,
      quarter: 90 * 24 * 60 * 60 * 1000,
      year: 365 * 24 * 60 * 60 * 1000,
    };
    
    const filterDate = args.period ? now - periodMs[args.period as keyof typeof periodMs] : 0;
    const filteredSales = sales.filter(sale => sale._creationTime >= filterDate);
    
    const totalRevenue = filteredSales
      .filter(sale => sale.status === "closed")
      .reduce((sum, sale) => sum + sale.amount, 0);
    
    const totalPipeline = filteredSales
      .filter(sale => sale.status === "pending")
      .reduce((sum, sale) => sum + (sale.amount * sale.probability / 100), 0);
    
    const conversionRate = filteredSales.length > 0 
      ? (filteredSales.filter(sale => sale.status === "closed").length / filteredSales.length) * 100
      : 0;
    
    const avgDealSize = filteredSales.length > 0
      ? totalRevenue / filteredSales.filter(sale => sale.status === "closed").length
      : 0;
    
    // Sales by category
    const categoryBreakdown = filteredSales.reduce((acc, sale) => {
      if (sale.status === "closed") {
        acc[sale.category] = (acc[sale.category] || 0) + sale.amount;
      }
      return acc;
    }, {} as Record<string, number>);
    
    // Sales by rep
    const repPerformance = filteredSales.reduce((acc, sale) => {
      if (sale.status === "closed") {
        acc[sale.salesRep] = (acc[sale.salesRep] || 0) + sale.amount;
      }
      return acc;
    }, {} as Record<string, number>);
    
    return {
      totalRevenue,
      totalPipeline,
      conversionRate,
      avgDealSize,
      categoryBreakdown,
      repPerformance,
      totalDeals: filteredSales.length,
      closedDeals: filteredSales.filter(sale => sale.status === "closed").length,
    };
  },
});

export const getForecast = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const pendingSales = await ctx.db
      .query("sales")
      .withIndex("by_status", (q) => q.eq("status", "pending"))
      .collect();
    
    const now = Date.now();
    const nextMonth = now + (30 * 24 * 60 * 60 * 1000);
    const nextQuarter = now + (90 * 24 * 60 * 60 * 1000);
    
    const monthlyForecast = pendingSales
      .filter(sale => sale.expectedCloseDate <= nextMonth)
      .reduce((sum, sale) => sum + (sale.amount * sale.probability / 100), 0);
    
    const quarterlyForecast = pendingSales
      .filter(sale => sale.expectedCloseDate <= nextQuarter)
      .reduce((sum, sale) => sum + (sale.amount * sale.probability / 100), 0);
    
    return {
      monthlyForecast,
      quarterlyForecast,
      totalPipeline: pendingSales.reduce((sum, sale) => sum + sale.amount, 0),
      weightedPipeline: pendingSales.reduce((sum, sale) => sum + (sale.amount * sale.probability / 100), 0),
    };
  },
});
