import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

export function Analytics() {
  const [period, setPeriod] = useState<"month" | "quarter" | "year">("month");
  const salesAnalytics = useQuery(api.sales.getAnalytics, { period });
  const customerAnalytics = useQuery(api.customers.getAnalytics);
  const forecast = useQuery(api.sales.getForecast);

  if (!salesAnalytics || !customerAnalytics || !forecast) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>
        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value as "month" | "quarter" | "year")}
          className="border border-gray-300 rounded-lg px-3 py-2"
        >
          <option value="month">Last 30 Days</option>
          <option value="quarter">Last 90 Days</option>
          <option value="year">Last Year</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnalyticsCard
          title="Total Revenue"
          value={`$${salesAnalytics.totalRevenue.toLocaleString()}`}
          subtitle={`${salesAnalytics.closedDeals} deals closed`}
        />
        <AnalyticsCard
          title="Pipeline Value"
          value={`$${salesAnalytics.totalPipeline.toLocaleString()}`}
          subtitle={`${salesAnalytics.totalDeals} total deals`}
        />
        <AnalyticsCard
          title="Conversion Rate"
          value={`${salesAnalytics.conversionRate.toFixed(1)}%`}
          subtitle="Closed vs Total"
        />
        <AnalyticsCard
          title="Avg Deal Size"
          value={`$${salesAnalytics.avgDealSize.toLocaleString()}`}
          subtitle="Closed deals only"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Sales by Category</h3>
          <div className="space-y-3">
            {Object.entries(salesAnalytics.categoryBreakdown).map(([category, amount]) => (
              <div key={category} className="flex justify-between items-center">
                <span className="text-gray-600">{category}</span>
                <span className="font-semibold">${amount.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Sales Rep Performance</h3>
          <div className="space-y-3">
            {Object.entries(salesAnalytics.repPerformance).map(([rep, amount]) => (
              <div key={rep} className="flex justify-between items-center">
                <span className="text-gray-600">{rep}</span>
                <span className="font-semibold">${amount.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Customer Distribution</h3>
          <div className="space-y-3">
            {Object.entries(customerAnalytics.statusCounts).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <span className="text-gray-600 capitalize">{status}</span>
                <span className="font-semibold">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Industry Breakdown</h3>
          <div className="space-y-3">
            {Object.entries(customerAnalytics.industryDistribution).map(([industry, count]) => (
              <div key={industry} className="flex justify-between items-center">
                <span className="text-gray-600">{industry}</span>
                <span className="font-semibold">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Revenue Forecast</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              ${forecast.monthlyForecast.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Next 30 Days</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              ${forecast.quarterlyForecast.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Next 90 Days</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              ${forecast.weightedPipeline.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Weighted Pipeline</div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface AnalyticsCardProps {
  title: string;
  value: string;
  subtitle: string;
}

function AnalyticsCard({ title, value, subtitle }: AnalyticsCardProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-sm font-medium text-gray-500 mb-2">{title}</h3>
      <div className="text-2xl font-bold text-gray-900 mb-1">{value}</div>
      <p className="text-sm text-gray-600">{subtitle}</p>
    </div>
  );
}
