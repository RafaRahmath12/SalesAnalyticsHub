import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Dashboard() {
  const customerAnalytics = useQuery(api.customers.getAnalytics);
  const salesAnalytics = useQuery(api.sales.getAnalytics, { period: "month" });
  const forecast = useQuery(api.sales.getForecast);
  const upcomingActivities = useQuery(api.activities.getUpcoming);

  if (!customerAnalytics || !salesAnalytics || !forecast || !upcomingActivities) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Revenue (Month)"
          value={`$${salesAnalytics.totalRevenue.toLocaleString()}`}
          subtitle={`${salesAnalytics.closedDeals} deals closed`}
          color="green"
        />
        <MetricCard
          title="Pipeline Value"
          value={`$${forecast.weightedPipeline.toLocaleString()}`}
          subtitle="Weighted by probability"
          color="blue"
        />
        <MetricCard
          title="Conversion Rate"
          value={`${salesAnalytics.conversionRate.toFixed(1)}%`}
          subtitle="This month"
          color="purple"
        />
        <MetricCard
          title="Avg Deal Size"
          value={`$${salesAnalytics.avgDealSize.toLocaleString()}`}
          subtitle="Closed deals"
          color="orange"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Sales Forecast</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Next 30 Days</span>
              <span className="font-semibold">${forecast.monthlyForecast.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Next 90 Days</span>
              <span className="font-semibold">${forecast.quarterlyForecast.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Pipeline</span>
              <span className="font-semibold">${forecast.totalPipeline.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Customer Overview</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Customers</span>
              <span className="font-semibold">{customerAnalytics.totalCustomers}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Active</span>
              <span className="font-semibold text-green-600">{customerAnalytics.statusCounts.active || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Prospects</span>
              <span className="font-semibold text-blue-600">{customerAnalytics.statusCounts.prospect || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Leads</span>
              <span className="font-semibold text-yellow-600">{customerAnalytics.statusCounts.lead || 0}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Upcoming Activities</h3>
        {upcomingActivities.length === 0 ? (
          <p className="text-gray-500">No upcoming activities scheduled</p>
        ) : (
          <div className="space-y-3">
            {upcomingActivities.slice(0, 5).map((activity) => (
              <div key={activity._id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div>
                  <div className="font-medium">{activity.customer?.name}</div>
                  <div className="text-sm text-gray-600">{activity.type} - {activity.description}</div>
                </div>
                <div className="text-sm text-gray-500">
                  {activity.scheduledFor && new Date(activity.scheduledFor).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: string;
  subtitle: string;
  color: "green" | "blue" | "purple" | "orange";
}

function MetricCard({ title, value, subtitle, color }: MetricCardProps) {
  const colorClasses = {
    green: "text-green-600 bg-green-50",
    blue: "text-blue-600 bg-blue-50",
    purple: "text-purple-600 bg-purple-50",
    orange: "text-orange-600 bg-orange-50",
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center">
        <div className={`p-2 rounded-lg ${colorClasses[color]}`}>
          <div className="w-6 h-6"></div>
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
          <p className="text-sm text-gray-500">{subtitle}</p>
        </div>
      </div>
    </div>
  );
}
